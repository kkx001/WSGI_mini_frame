import sys

print(sys.argv)

# 运行次程序的方式： python3 xxx.py haha 7890
